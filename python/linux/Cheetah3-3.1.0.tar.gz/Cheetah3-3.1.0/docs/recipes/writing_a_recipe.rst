Writing a "Recipe"
==================

This document isn't quite there yet ;)
