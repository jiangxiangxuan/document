Files
=====

(files)

This chapter will be an overview of the files in the Cheetah
package, and how they interrelate in compiling and filling a
template. We'll also look at files in the Cheetah tarball that
don't get copied into the package.


