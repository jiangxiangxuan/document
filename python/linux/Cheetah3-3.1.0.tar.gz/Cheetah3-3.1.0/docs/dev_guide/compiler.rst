The compiler
============

(compiler)

How templates are compiled: a walk through Compiler.py.


