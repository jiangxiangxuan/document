Cheetah\.Templates\.SkeletonPage module
=======================================

.. automodule:: Cheetah.Templates.SkeletonPage
    :members:
    :undoc-members:
    :show-inheritance:
