Cheetah\.DummyTransaction module
================================

.. automodule:: Cheetah.DummyTransaction
    :members:
    :undoc-members:
    :show-inheritance:
