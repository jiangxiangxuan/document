.. cmake-module:: ../../Modules/FindJava.cmake
